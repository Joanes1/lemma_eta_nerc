from django.urls import path
from . import views


urlpatterns = [
    path('hasiera/', views.home, name='home'), 
    path('hasieraLema/', views.lematizatzailea_app, name='lematizatzailea_app'),
    path('', views.invitado, name='invitado'),
    path('register/', views.register, name='register'),
    path('login/', views.user_login, name='login'),
    path('guest/', views.invitado, name='invitado'),
    path('guestEmaitzak/', views.emaitzak_invitado, name='invitadoEmaitzak'),
    path('emaitzak/', views.lortu_emaitza, name='emaitzak'),
    path('history/', views.kontsultak_ikusi, name='history'),
    path('logout/', views.user_logout, name='logout'),
    path('kontsulta/delete/<int:kontsulta_id>/', views.delete_kontsulta, name='delete_kontsulta'),
    path('switchboard/lema/', views.emaitzak_invitado_switchboard, name='emaitzak_switchboard'),
    path('switchboard/lema/emaitzak', views.render_emaitzak_page_switchboard, name='emaitzak_page'),
    path('api/lemma', views.lematizaioa_api, name='lemma_api'),
    
]
