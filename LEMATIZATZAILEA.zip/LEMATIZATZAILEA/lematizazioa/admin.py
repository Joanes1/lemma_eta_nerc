from django.contrib import admin
from .models import Kontsultak, EmaitzaFormatua


admin.site.register(Kontsultak)
admin.site.register(EmaitzaFormatua)
# Register your models here.
