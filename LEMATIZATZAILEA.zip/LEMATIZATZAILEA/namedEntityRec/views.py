import os
from urllib.parse import unquote
from django.shortcuts import redirect, render
from django.http import HttpResponse, JsonResponse
from django.contrib.auth.decorators import login_required
from django.utils.translation import gettext as _
from django.conf import settings
import requests
from .ner import nerc_funtzioa_text
from django.views.decorators.http import require_http_methods
import json
from .forms import NerForm
from .laguntzaileak import set_anonymous_id, juntatu_underlined, txukundu_nerc_apiarentzat, extract_number, karpeta_sortu, testua_to_txt, ner_aplikatu,  txt_to_json, generate_wordcloud, filter_ner_results
from django.views.decorators.csrf import csrf_exempt

#nerc egiteko orrialdea
def nerHome(request):
    form = NerForm()
    return render(request, 'homeNer.html', {'form': form})


#NERC kudeatu
def ner(request):
    if request.method == 'POST':
        form = NerForm(request.POST)
        if form.is_valid():
            anonymous_id = set_anonymous_id(request)
            text = form.cleaned_data['text_area'] #erabiltzaileak igotako testua eskuratu
            testua_to_txt(text, anonymous_id) #testua txt fitxategian kopiatu
            nFiles = os.listdir(settings.NER_FITXATEGIAK)
            nFile = next((f for f in nFiles if anonymous_id in f), None)
            print(nFile)
            karpeta_sortu(settings.NER_EMAITZAK_UNDERLINED)
            karpeta_sortu(settings.NER_ONLY_UNDERLINED)
            ner_results = ner_aplikatu(os.path.join(settings.NER_FITXATEGIAK, nFile), anonymous_id) 
            #entitateak aurkitu badira, horiekin formatu desberdinetako emaitzak prestatu. bestela erabiltzaileari ezer ez dela aurkitu adierazi.. 
            if ner_results:          
                request.session['ner_results'] = filter_ner_results(ner_results)
                nFileEmaitzak = os.listdir(settings.NER_EMAITZAK)
                nFileEmaitza = next((f for f in nFileEmaitzak if anonymous_id in f), None)
                juntatu_underlined(anonymous_id)
                emaitzakF = os.listdir(settings.NER_EMAITZAK_UNDERLINED_FINAL)
                emaitzaF = next((f for f in emaitzakF if anonymous_id in f), None)
                under_s_files = os.listdir(settings.NER_ONLY_UNDERLINED)
                under_s = next((f for f in under_s_files if anonymous_id in f), None)
                files_under_sorted = sorted(
                    under_s,
                    key=lambda x: (extract_number(x, r'par(\d+)'), extract_number(x, r'sent(\d+)'))
                )
                under_sent_contents = []

                
                for filename in files_under_sorted:
                    file_path = os.path.join(settings.NER_ONLY_UNDERLINED, filename)
                    
                    if os.path.isfile(file_path):  
                        with open(file_path, "r", encoding="utf-8") as file:
                            under_sent_contents.append(file.read())

                with open(os.path.join(settings.NER_EMAITZAK_UNDERLINED_FINAL, emaitzaF), encoding='utf-8') as file:
                    emaitzaText = file.read()

                txt_to_json(os.path.join(settings.NER_EMAITZAK, nFileEmaitza), anonymous_id)
                jsonFiles = os.listdir(settings.NER_EMAITZAK_JSON)
                jsonFile = next((f for f in jsonFiles if anonymous_id in f), None)
                org =[]
                loc = []
                per = []
                misc = []

                generate_wordcloud(ner_results, anonymous_id)
                wordcloudFiles = os.listdir(settings.NER_WORDCLOUD)[0]
                wordcloudFile = next((f for f in wordcloudFiles if anonymous_id in f), None)
                for entity in ner_results:
                    if entity['entity_group'] == "ORG":
                        org.append(entity['word'])
                    elif entity['entity_group'] == "LOC":
                        loc.append(entity['word'])
                    elif entity['entity_group'] == "PER":
                        per.append(entity['word'])
                    elif entity['entity_group'] == "MISC":
                        misc.append(entity['word'])
                
                org_text = ", ".join(org)  
                loc_text = ", ".join(loc)
                per_text = ", ".join(per)
                misc_text = ", ".join(misc)

                request.session['emaitzaText'] = emaitzaText
                request.session['per_text'] = per_text
                request.session['loc_text'] = loc_text
                request.session['org_text'] = org_text
                request.session['misc_text'] = misc_text
                request.session['nFileEmaitza'] = nFileEmaitza
                request.session['jsonFile'] = jsonFile
                request.session['wordcloudFile'] = wordcloudFile
                request.session['under_sent_contents'] = under_sent_contents

                return render(request, 'emaitzaNer.html', {'emaitza': emaitzaText, 
                                                        'per': per_text, 
                                                        'loc': loc_text, 
                                                        'org':org_text, 
                                                        'misc': misc_text,
                                                        'MEDIA_URL':settings.MEDIA_URL,
                                                        'txt_file': nFileEmaitza,
                                                        'json_file':jsonFile,
                                                        'wordcloud':wordcloudFile,
                                                        'under_sent':under_sent_contents,
                                                        'anonymous_id':anonymous_id
                                                        })
            else:
                form = NerForm()
                error = _("No entities were recognized in the provided text.") 
                return render(request, 'homeNer.html', {'form': form, 'errorea':error})
                

    else:
        form = NerForm()
        return render(request, 'homeNer.html', {'form': form}) 

#taula erakusteko funtzioa
def tabla_ikusi(request):
    ner_results = request.session.get('ner_results', [])
    return render(request, 'ner_taula.html', {'entities': ner_results})

#nerc switchboardetik atzitzeko 
@csrf_exempt
def nerc_switchboard(request):
    if request.method == 'GET':  
        try:
            data_url = request.GET.get('data', '').strip()
            if not data_url:
                return JsonResponse({'error': 'Ez duzu datu URLrik sartu.'}, status=400)

            decoded_url = unquote(data_url)

            response = requests.get(decoded_url)
            if response.status_code != 200:
                return JsonResponse({'error': 'Ezin izan da testua deskargatu.'}, status=400)

            text = response.text.strip() 
            if not text:
                return JsonResponse({'error': 'Deskargatutako fitxategia hutsik dago.'}, status=400)

            anonymous_id = set_anonymous_id(request)
            testua_to_txt(text, anonymous_id) #testua txt fitxategian kopiatu
            nFile = os.listdir(settings.NER_FITXATEGIAK)[0]
            karpeta_sortu(settings.NER_EMAITZAK_UNDERLINED)
            karpeta_sortu(settings.NER_ONLY_UNDERLINED)
            ner_results = ner_aplikatu(os.path.join(settings.NER_FITXATEGIAK, nFile), anonymous_id) 
            #entitateak aurkitu badira, horiekin formatu desberdinetako emaitzak prestatu. bestela erabiltzaileari ezer ez dela aurkitu adierazi.. 
            if ner_results:          
                request.session['ner_results'] = filter_ner_results(ner_results)
                nFileEmaitza = os.listdir(settings.NER_EMAITZAK)[0]
                juntatu_underlined(anonymous_id)
                emaitzaF = os.listdir(settings.NER_EMAITZAK_UNDERLINED_FINAL)[0]
                
                under_s = os.listdir(settings.NER_ONLY_UNDERLINED)
                files_under_sorted = sorted(
                    under_s,
                    key=lambda x: (extract_number(x, r'par(\d+)'), extract_number(x, r'sent(\d+)'))
                )
                under_sent_contents = []

                
                for filename in files_under_sorted:
                    file_path = os.path.join(settings.NER_ONLY_UNDERLINED, filename)
                    
                    if os.path.isfile(file_path):  
                        with open(file_path, "r", encoding="utf-8") as file:
                            under_sent_contents.append(file.read())

                with open(os.path.join(settings.NER_EMAITZAK_UNDERLINED_FINAL, emaitzaF), encoding='utf-8') as file:
                    emaitzaText = file.read()

                txt_to_json(os.path.join(settings.NER_EMAITZAK, nFileEmaitza), anonymous_id)
                jsonFile = os.listdir(settings.NER_EMAITZAK_JSON)[0]
                
                org =[]
                loc = []
                per = []
                misc = []

                generate_wordcloud(ner_results, anonymous_id)
                wordcloudFile = os.listdir(settings.NER_WORDCLOUD)[0]

                for entity in ner_results:
                    if entity['entity_group'] == "ORG":
                        org.append(entity['word'])
                    elif entity['entity_group'] == "LOC":
                        loc.append(entity['word'])
                    elif entity['entity_group'] == "PER":
                        per.append(entity['word'])
                    elif entity['entity_group'] == "MISC":
                        misc.append(entity['word'])
                
                org_text = ", ".join(org)  
                loc_text = ", ".join(loc)
                per_text = ", ".join(per)
                misc_text = ", ".join(misc)

                request.session['emaitzaText'] = emaitzaText
                request.session['per_text'] = per_text
                request.session['loc_text'] = loc_text
                request.session['org_text'] = org_text
                request.session['misc_text'] = misc_text
                request.session['nFileEmaitza'] = nFileEmaitza
                request.session['jsonFile'] = jsonFile
                request.session['wordcloudFile'] = wordcloudFile
                request.session['under_sent_contents'] = under_sent_contents


            return redirect('nerc_page')  

        except Exception as e:
            return JsonResponse({'error': f'Unexpected error occurred: {str(e)}'}, status=500)

    return JsonResponse({'error': 'Only GET method is allowed.'}, status=405)


def tabla_to_emaitza(request):
     # Retrieve session variables
    emaitzaText = request.session.get('emaitzaText', '')
    per_text = request.session.get('per_text', '')
    loc_text = request.session.get('loc_text', '')
    org_text = request.session.get('org_text', '')
    misc_text = request.session.get('misc_text', '')
    nFileEmaitza = request.session.get('nFileEmaitza', '')
    jsonFile = request.session.get('jsonFile', '')
    wordcloudFile = request.session.get('wordcloudFile', '')
    under_sent_contents = request.session.get('under_sent_contents', [])
    anonymous_id = request.session.get('anonymous_id')
    return render(request, 'emaitzaNer.html', {
        'emaitza': emaitzaText, 
        'per': per_text, 
        'loc': loc_text, 
        'org': org_text, 
        'misc': misc_text,
        'MEDIA_URL': settings.MEDIA_URL,
        'txt_file': nFileEmaitza,
        'json_file': jsonFile,
        'wordcloud': wordcloudFile,
        'under_sent': under_sent_contents,
        'anonymous_id':anonymous_id
    })

def render_nerc_page_switchboard(request):
    # Retrieve session variables
    emaitzaText = request.session.get('emaitzaText', '')
    per_text = request.session.get('per_text', '')
    loc_text = request.session.get('loc_text', '')
    org_text = request.session.get('org_text', '')
    misc_text = request.session.get('misc_text', '')
    nFileEmaitza = request.session.get('nFileEmaitza', '')
    jsonFile = request.session.get('jsonFile', '')
    wordcloudFile = request.session.get('wordcloudFile', '')
    under_sent_contents = request.session.get('under_sent_contents', [])
    anonymous_id = request.session.get('anonymous_id')
    return render(request, 'emaitzaNer.html', {
        'emaitza': emaitzaText, 
        'per': per_text, 
        'loc': loc_text, 
        'org': org_text, 
        'misc': misc_text,
        'MEDIA_URL': settings.MEDIA_URL,
        'txt_file': nFileEmaitza,
        'json_file': jsonFile,
        'wordcloud': wordcloudFile,
        'under_sent': under_sent_contents,
        'anonymous_id':anonymous_id
    })


@csrf_exempt  
@require_http_methods(["POST"]) 
def nerc_api(request):
    try:
        # Parse the JSON body
        body = json.loads(request.body.decode('utf-8')) #POST eskaeraren body
        text = body.get('text', '').strip() # eskaerako body-tik text atributuko edukia eskuratu
        if not text:
            return JsonResponse({'error': 'No text provided for lemmatization'}, status=400)
        
        emaitza = nerc_funtzioa_text(text)
        emaitzajson = txukundu_nerc_apiarentzat(emaitza)
        return JsonResponse({'emaitza': emaitzajson})

    except Exception as e:
        return JsonResponse({'error': f'An error occurred: {str(e)}'}, status=500)