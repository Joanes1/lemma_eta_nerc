import os
import re
import shutil
import json

from sympy import Integer

from django.conf import settings
from .ner import nerc_funtzioa

from wordcloud import WordCloud

#jasotako edukia txt fitxategi batean kopiatu eta gorde
def testua_to_txt(testua):
    karpeta_sortu(settings.NER_FITXATEGIAK)
    namef = f"nerInput.txt"
    input = os.path.join(settings.NER_FITXATEGIAK, namef)
 
    with open(input, mode='w', encoding='utf-8') as txtfile:
        txtfile.write(testua)

#fitxategi bateko edukiari NERC aplikatzeko funtzioa
def ner_aplikatu(file):
    karpeta_sortu(settings.NER_EMAITZAK)
    
    namef = f"nerOutput.txt"
    emaitza = os.path.join(settings.NER_EMAITZAK, namef)
    nerc_results = nerc_funtzioa(file)

    with open(emaitza, mode='w', encoding='utf-8') as txtfile:
        for entity in nerc_results:
            text = f"Word: {entity['word']}, Entity Group: {entity['entity_group']}\n"
            txtfile.write(text)

    return nerc_results
    
#fitxategiaren izenetik zenbatgarren paragrafo eta esaldiari dagokion esaldia den eskuratu
def extract_number(file_name, pattern):
    """Extracts the first number found in a filename based on a given pattern."""
    match = re.search(pattern, file_name)
    return int(match.group(1)) if match else float('inf')

#entitateak azpimarratuta dituzten esaldien fitxategi desberdinak fitxategi bakar batean jarri
def juntatu_underlined():
    files_under = os.listdir(settings.NER_EMAITZAK_UNDERLINED)
    
    
    files_under_sorted = sorted(
        files_under,
        key=lambda x: (extract_number(x, r'par(\d+)'), extract_number(x, r'sent(\d+)'))
    )

    karpeta_sortu(settings.NER_EMAITZAK_UNDERLINED_FINAL)
    final_output_path = os.path.join(settings.NER_EMAITZAK_UNDERLINED_FINAL, "finalUnder_output.txt")

    parrafo1 = 1
    with open(final_output_path, 'w', encoding='utf-8') as final_file:
        
        for file_name in files_under_sorted:
            file_path = os.path.join(settings.NER_EMAITZAK_UNDERLINED, file_name)
            par = re.search(r'par(\d+)', file_name)
            parrafo2 = int(par.group(1))
            if parrafo2 != parrafo1:
                if os.path.isfile(file_path):
                    with open(file_path, 'r', encoding='utf-8') as f:
                        final_file.write("<br><br>" + f.read() + " ")
            else: 
                if os.path.isfile(file_path):
                    with open(file_path, 'r', encoding='utf-8') as f:
                        final_file.write(f.read() + " ")
            parrafo1 = parrafo2

            

    





#def nerEmaitza_json_form():


def karpeta_sortu(karpeta):
    folder_path = os.path.abspath(karpeta)
    if os.path.exists(folder_path):
        for item in os.listdir(folder_path):
            item_path = os.path.join(folder_path, item)
            if os.path.isfile(item_path) or os.path.islink(item_path):
                os.unlink(item_path)  
            elif os.path.isdir(item_path):
                shutil.rmtree(item_path)  
    else:
        os.makedirs(folder_path)

#json formatuko emaitza sortzeko funtzioa
def txt_to_json(input_file):
    karpeta_sortu(settings.NER_EMAITZAK_JSON)
    with open(input_file, 'r') as file:
        lines = file.readlines()
    
    data = []
    
    for line in lines:
        parts = [part.strip() for part in line.split(',')]
        
        word = parts[0].replace('Word: ', '')
        entity_group = parts[1].replace('Entity Group: ', '')
        
        data.append({"Word": word, "Entity Group": entity_group})
    
    namef = f"nerOutput.json"
    emaitza_file = os.path.join(settings.NER_EMAITZAK_JSON, namef)
    with open(emaitza_file, 'w') as json_file:
        json.dump(data, json_file, indent=2)

#emaitza wordcloud formatuan sortzeko
def generate_wordcloud(entities):
    if entities:
        karpeta_sortu(settings.NER_WORDCLOUD)
        
        words = [entity['word'] for entity in entities]
        wordcloud = WordCloud(width=800, height=400).generate(' '.join(words))

        image = os.path.join(settings.NER_WORDCLOUD, 'wordcloud.png')

        wordcloud.to_file(image)

#NERC emaitzak itzultzen duen informazioa fitratu, soilik interesatzen zaizkigun datuak hartzeko
def filter_ner_results(ner_results):
    """
    Remove unnecessary fields like 'score' from the NER results.
    """
    return [
        {key: value for key, value in entity.items() if key != 'score'}
        for entity in ner_results
    ]


