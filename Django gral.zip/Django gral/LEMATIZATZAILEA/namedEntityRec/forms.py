from django import forms

#NERC egiteko formularioa, nahiz eta NerForm deitzen den
class NerForm(forms.Form):
    text_area = forms.CharField(
        widget=forms.Textarea(attrs={'rows': 20, 'cols': 100}),
        required=True
    )