from django.conf import settings
from transformers import pipeline
from typing import List, Dict
from functools import lru_cache
import re, os


MODEL_NAME = "orai-nlp/ElhBERTeu-nerc"
STRIDE = 100
AGGREGATION_STRATEGY = "simple"

class NERCService:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(NERCService, cls).__new__(cls)
            cls._instance._initialize_model()
        return cls._instance

    def _initialize_model(self):
        """
        Initialize the token classification pipeline.
        """
        self.classifier = self._load_ner_pipeline()

    @lru_cache(maxsize=1)
    def _load_ner_pipeline(self):
        """
        Load the NER model pipeline with caching.
        """
        return pipeline(
            "ner",
            model=MODEL_NAME,
            stride=STRIDE,
            aggregation_strategy=AGGREGATION_STRATEGY,
        )

    def predict(self, text: str) -> List[Dict]:
        """
        Perform named entity recognition on the input text.

        :param text: Input text to process
        :return: List of recognized entities
        """
        return self.classifier(text)

# Create a singleton service instance
nerc_service = NERCService()

# Function to perform NERC on text file
import os
import re

#Apply NERC to then content that is on a file
def nerc_funtzioa(file_path) -> tuple:
    with open(file_path, 'r', encoding='utf-8') as file:
        text = file.read()

    # Step 1: Split text into paragraphs (based on double newlines)
    paragraphs = re.split(r'\n\s*\n', text.strip())

    all_results = []
    kont_paragraph = 0  # Paragraph counter

    for paragraph in paragraphs:
        kont_paragraph += 1

        if paragraph.strip():
            # Step 2: Split paragraph into sentences
            sentences = re.split(r'(?<=[.!?])\s+', paragraph)

            kont_sentence = 0  # Sentence counter within paragraph
            for sentence in sentences:
                kont_sentence += 1

                if sentence.strip():
                    results = nerc_service.predict(sentence)  # Run NERC on the sentence
                    underline_ner_entities(results, sentence, kont_paragraph, kont_sentence)
                    all_results.extend(results)
    
    return all_results

#Underline NERC entities in a sentence. NERC entitateak azpimarratu
def underline_ner_entities(ner_results, sentence, kont_paragraph, kont_sentence):
    """Save each underlined sentence as a separate file, named by paragraph & sentence number"""
    
    # Name each file as "nerOutput_parX_sentY.txt"
    namef = f"nerOutput_par{kont_paragraph}_sent{kont_sentence}.txt"
    emaitza_under = os.path.join(settings.NER_EMAITZAK_UNDERLINED, namef)
    
    characters = list(sentence)  
    padd = 0  

    if ner_results: 
        for result in ner_results:
            color = get_entity_color(result['entity_group'])
            start = result['start'] + padd
            end = result['end'] + padd

            characters.insert(start, f'<span style="color:{color};"><b><u>')
            characters.insert(end+1, '</b></u></span>')

            padd += 2

    output_text = "".join(characters)


    if ner_results:
        namef2 = f"nerOutput_par{kont_paragraph}_sent{kont_sentence}.txt"
        emaitza_under2 = os.path.join(settings.NER_ONLY_UNDERLINED, namef2)
        with open(emaitza_under2, mode="w", encoding="utf-8") as undertxt2:  
            undertxt2.write(output_text)

    # Save each sentence as a separate file
    with open(emaitza_under, mode="w", encoding="utf-8") as undertxt:  
        undertxt.write(output_text)

#entitate bakoitza zer koloretan azpimarratu behar den definitzeko
def get_entity_color(entityGr):
    if entityGr == "PER":
        return "red"  # Person
    elif entityGr == "LOC":
        return "blue"  # Location
    elif entityGr == "ORG":
        return "green"  # Organization
    elif entityGr == "MISC":
        return "purple"  # Miscellaneous
    else:
        return "black"  # Default color 
    