from django.urls import path
from . import views


urlpatterns = [
    path('nerHome/', views.nerHome, name='nerHome'),   
    path('ner/', views.ner, name='nerEgin'),
    path('ner_table/', views.tabla_ikusi, name='tabla'),
    path('switchboard/nerc/', views.nerc_switchboard, name='nerc_switchboard'),
    path('switchboard/nerc/emaitzak', views.render_nerc_page_switchboard, name='nerc_page'),
    path('nercEmaitzak/', views.tabla_to_emaitza, name='tablaToEmaitza')
]
