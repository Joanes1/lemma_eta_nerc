# lematizazioa/forms.py
# Djangoko formularioak definitzeko fitxategia
from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from django.utils.translation import gettext_lazy as _

# Erregistrorako formularioa
class RegisterForm(UserCreationForm):
    email = forms.EmailField()
    
    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']


# Fitxategientzako formularioa

class MultipleFileInput(forms.ClearableFileInput):
    allow_multiple_selected = True


class MultipleFileField(forms.FileField):
    def __init__(self, *args, **kwargs):
        kwargs.setdefault("widget", MultipleFileInput())
        super().__init__(*args, **kwargs)

    def clean(self, data, initial=None):
        single_file_clean = super().clean
        if isinstance(data, (list, tuple)):
            result = [single_file_clean(d, initial) for d in data]
        else:
            result = [single_file_clean(data, initial)]
        return result


class FileFieldForm(forms.Form):
    file_field = MultipleFileField(required=False)


#Lematizaziorako formularioa
class LematizationForm(forms.Form, MultipleFileField):
    OPTIONS_CHOICES = [
        ('1', _("Pantailan erakutsi")),
        ('2', _("Fitxategia pdf formatuan")),
        ('3', _("Fitxategia csv formatuan")),
        ('4', _("Fitxategia CoNLL formatuan")),
        ('5', _("Fitxategia JSON formatuan")),
    ]

    option = forms.ChoiceField(
        choices=[('text', _("Testua idatzi")), ('upload', _("Fitxategia igo"))],
        widget=forms.RadioSelect,
        required=True,
        initial='text'
    )

    
    text_area = forms.CharField(
        widget=forms.Textarea(attrs={'rows': 20, 'cols': 100}),
        required=False
    )
    
    options = forms.MultipleChoiceField(
        choices=OPTIONS_CHOICES,
        widget=forms.CheckboxSelectMultiple,
        required=False
    )



# Erabitzaile gonbidatuek lematizazioa egiteko formularioa
class LematizationInvitado(forms.Form):
    text_area = forms.CharField(
        widget=forms.Textarea(attrs={'rows': 20, 'cols': 100})
    )

